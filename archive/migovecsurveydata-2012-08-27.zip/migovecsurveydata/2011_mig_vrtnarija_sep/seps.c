struct{
int x,y,z;
char name[50];
}pos;

main{}
{
 struct pos a[2000], b[2000];

 
}
