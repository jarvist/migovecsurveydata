cavern sysmig_vrtnarija.svx 
extend --specfile sysmig_vrtnarija_extend_spec_2012.dat sysmig_vrtnarija.3d 
~/survex-1.2.6/src/aven sysmig_vrtnarija_extend.3d 
