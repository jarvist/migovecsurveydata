for file in `find -name '*.err'`;
do `rm -f $file`
done

for file in `find -name '*.inf'`;
do `rm -f $file`
done

for file in `find -name '*.3d'`;
do `rm -f $file`
done

